import React from 'react';
import axios from 'axios';
import Constants from 'expo-constants';
import { FlatList, ActivityIndicator, StyleSheet, Image, Text, View,Dimensions,TouchableOpacity } from 'react-native';
 
// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;
export default class Layout3 extends React.Component {
   constructor(props) {
       super(props);
       this.state = { isLoading: true };
   }
 
   componentDidMount() {
       axios.get(`https://morning-escarpment-62298.herokuapp.com/api/fasilitas`)
           .then(response => {
               console.log(response.data)
               this.setState(
                   {
                       isLoading: false,
                       dataSource: response.data
                   })
           })
           .catch(error => {
               console.log(error)
           })
   }
 
   render() {
       return (
          <View>
    <View style={styles.container}>
      <View style={styles.Search} >
       <Ionicons name="arrow-back-sharp" size={25} color="black"/>
      <Text
      style={{
        width:320,
        height:20,
        fontWeight:"bold",
        marginLeft:245}}>
      <Ionicons name="reorder-four-outline" size={25} color="black"/> 
      </Text>
      </View>
      <View
        style={{
          justifyContent:'center',
          alignItems:"center"
        }}>
        <Text
        style={{
        color:'#2A2E3A',
        width:120,
        fontWeight:'Algerian',
        
        justifyContent:'center',
        fontSize:30}}>
        Fasilitas </Text>
        <Text
        style={{
        color:'#2A2E3A',
        width:150,
        fontWeight:'Algerian',
        alignItems:'center',
        justifyContent:'center',
        fontSize:25}}>
        Peminjaman </Text>
        </View>
        <FlatList
        numColumns = {2}
        style={{
          alignItems:'center'
        }}
                   data={this.state.dataSource}
                   renderItem={({ item }) => (
                     <>
        <View style={styles.Menu1}>
        <View
        style={{
          width:150,
          height:150,
          borderColor:'#000000',
          borderWidth:0,
          borderRadius:40,
          alignItems:'center',
          margin:5,
          justifyContent:'flex-end'}}>
      <Image style={styles.logo1} source={{uri:'https://morning-escarpment-62298.herokuapp.com/gambar/'+item.foto}}/>
        <Text
        style={{
          height:30,
          marginTop:6,
          lignItems:'center',
          justifyContent:'center',
          fontWeight: 'bold',
          fontSize:17}}>
          {item.nama_peminjam}
        </Text>
        <Text
        style={{
          height:30,
          marginTop:6,
          lignItems:'center',
          justifyContent:'center',
          fontWeight: 'bold',
          fontSize:14}}>
          {item.nama_barang}
          
        </Text>
        <Text
        style={{
          height:30,
          marginTop:6,
          lignItems:'center',
          justifyContent:'center',
          fontWeight: 'bold',
          fontSize:10}}>
          {item.tgl_peminjaman}
        </Text>
        
      </View>

        </View>
         </>
                      )}
                   keyExtractor={({ id }, index) => id}
        />

        </View>
        <View style={styles.buttomMenu}>
      <View>
         <TouchableOpacity onPress={()=>this.props.navigation.navigate('Layout5')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>10</Text></View>
          <Ionicons name="home" size={25} color="black"/>
      </TouchableOpacity>
      </View>
      

      <View>
      <TouchableOpacity onPress={()=>this.props.navigation.navigate('Layout3')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>1</Text></View>
      <Ionicons name="briefcase-sharp" size={25} color="black"/>
      </TouchableOpacity>
      </View>
      

      <View>
          <TouchableOpacity onPress={()=>this.props.navigation.navigate('Layout1')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>1</Text></View>
      <Ionicons name="calendar-sharp" size={25} color="black"/>
      </TouchableOpacity>
      </View>

      <View>
          <TouchableOpacity onPress={()=>this.props.navigation.navigate('Layout2')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>1</Text></View>
      <Ionicons name="finger-print-sharp" size={25} color="black"/>
      </TouchableOpacity>
      </View>

      </View>
    </View>
       );
   }
 
}
const styles = StyleSheet.create({
  buttomMenu:{
    height:70,
    backgroundColor:'#5caaf0',
    borderRadius:25,
    position:"relative",
    flexDirection:'row',
    justifyContent:"space-around",
    top:windowHeight-700,
    alignItems:'center',
    zIndex:9999
  },
  container: {
    flex: 4,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'white',
    padding:4,
  },
  Search: {
    flexDirection: 'row',
    margin: 15,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    justifyContent:"space-between"    
  },
  Menu1: {
    fontSize: 20,
    marginTop:5,
    fontWeight: 'bold',
    textAlign: 'center',
    justifyContent:'space-around',
    flexDirection:'row',
  },
  
  textbox: { 
    padding:10,
    flexDirection:'row',
    alignItems:'center',
    backgroundColor:'#d4d4d2',
    height:70,
    justifyContent:'center',
    borderRadius:30,
    marginTop:20
  },
  logo1:{
    height:80,
    width:80,
    borderRadius:1000,
    borderWidth:1,
    position:'flex'
    
  },
  logo2:{
    height:325,
    width:300,
    left:10,
    position:'flex'
    
  },
});
