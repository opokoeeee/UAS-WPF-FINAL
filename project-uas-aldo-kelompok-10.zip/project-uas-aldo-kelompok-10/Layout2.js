import React,{useState,useEffect} from 'react';
import { Text, View, StyleSheet, Image ,Dimensions,TouchableOpacity,FlatList} from 'react-native';
import Constants from 'expo-constants';
import axios from 'axios';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;
export default function App({navigation}) {
  const [poster,setPoster]=useState([])
   const getPoster = async () => {
    try {
      const dataIsi = await axios.get(
        'https://morning-escarpment-62298.herokuapp.com/api/pj'
      );
      setPoster(dataIsi.data);
      console.log(dataIsi.data);
    } catch (err) {
      const dataIsi = await axios.get(
        'https://morning-escarpment-62298.herokuapp.com/api/acara'
      );
      setPoster(dataIsi.data2);
      console.log(dataIsi.data2);
    
      console.error(err.message);
    }
  };
  useEffect(()=>{
    getPoster()
},[])
    return(
    <View>
    <View style={styles.container}>
      <View style={styles.Search}>
      
      <Ionicons name="arrow-back-sharp" size={25} color="black"/>
      
      
      <Text
     style={{
       width:320,
        height:20,
        fontWeight:"bold",
        marginLeft:225}}>
       <Ionicons name="heart-circle-sharp" size={35} color="red"/> 
    </Text>
    
      </View>
      <View>

     <Image style={styles.logo2} source={{uri:'https://pmb.pcr.ac.id//uploads/media/Jadwal_Penting_Terbaru_untuk_Mahasiswa_Baru_Politeknik_Caltex_Riau_202020200805075151.jpg'}}/>
      </View>
      <View
        style={{
          backgroundColor:'#ecbc4f',
          height:430,
          marginTop:-80,
          borderRadius:30,
          width:319.9,
          marginLeft:-5
        }}
        >
       <View
       style={{
         marginTop : 15,
         marginBottom:15,
         

       }}>
       <center>
        <Text
            style={{
        color:'#2A2E3A',
        fontWeight:'Bold',
        fontSize:15
        }}>
        Nama-Nama Penanggung Jawab
        </Text>
        </center>
        </View>
        <FlatList
        
                   data={poster}
                   renderItem={({ item }) => (
                     <>
        <View
         style={{
         flex:1,
         height:20,
         borderRadius:35,
         justifyContent:"space-around",
         flexDirection:'row',
         padding:20
       }}>
        <View>
        <Text
        style={{
        color:'#2A2E3A',
        width:200,
        fontWeight:'Algerian',
        
        fontSize:18}}>
      {item.nama}</Text>
        </View>
        <View
        style={{
        color:'#2A2E3A',
        width:40,
        fontWeight:'Algerian',
        fontSize:10
      }}
        >
          <Text
        style={{
        color:'#2A2E3A',
        width:50,
        height:5,
        fontWeight:'Algerian',
        
        fontSize:18
      }}> {item.nama_acara}</Text>
        </View>
        
        </View>
         </>
                      )}
                   keyExtractor={({ id }, index) => id}
        />
        <View>
        <Text
        style={{
        flexWrap:"center",
        color:'#2A2E3A',
        width:300,
        marginLeft:20,
        marginTop:-75,
        height:20,
        fontWeight:'Algerian',
        fontSize:12
      }}> 
        
        </Text>
      </View>
        <View
         style={{
         flex:1,
         height:70,
         borderRadius:20,
         justifyContent:"space-around",
         flexDirection:'row',
         padding:40
       }}>
        
        
        </View>
        <View>
        </View>
        
        

        </View>


           
    </View>
    <View style={styles.buttomMenu}>
      <View>
         <TouchableOpacity onPress={()=>navigation.navigate('Layout5')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>10</Text></View>
          <Ionicons name="home" size={25} color="black"/>
      </TouchableOpacity>
      </View>
      

      <View>
      <TouchableOpacity onPress={()=>navigation.navigate('Layout3')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>1</Text></View>
      <Ionicons name="briefcase-sharp" size={25} color="black"/>
      </TouchableOpacity>
      </View>
      

      <View>
          <TouchableOpacity onPress={()=>navigation.navigate('Layout1')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>1</Text></View>
      <Ionicons name="calendar-sharp" size={25} color="black"/>
      </TouchableOpacity>
      </View>

      <View>
          <TouchableOpacity onPress={()=>navigation.navigate('Layout2')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>1</Text></View>
      <Ionicons name="finger-print-sharp" size={25} color="black"/>
      </TouchableOpacity>
      </View>

      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  buttomMenu:{
    height:70,
    backgroundColor:'#5caaf0',
    borderRadius:25,
    position:"relative",
    flexDirection:'row',
    justifyContent:"space-around",
    top:windowHeight-755,
    alignItems:'center',
    zIndex:9999
  },
  container: {
    flex: 4,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'white',
    padding:4,
  },
  Search: {
    flexDirection: 'row',
    margin: 15,
    height:20,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    justifyContent:"space-between"    
  },
  Menu1: {
    fontSize: 20,
    marginTop:5,
    fontWeight: 'bold',
    textAlign: 'center',
    justifyContent:'space-around',
    flexDirection:'row',
  },
  
  textbox: { 
    padding:10,
    flexDirection:'row',
    alignItems:'center',
    backgroundColor:'#d4d4d2',
    height:70,
    justifyContent:'center',
    borderRadius:30,
    marginTop:20
  },
  logo1:{
    height:55,
    width:75,
    borderRadius:20,
    borderWidth:1,
    position:'flex'
    
  },
  logo2:{
    height:250,
    width:320,
    marginLeft:-5 ,
    position:'flex'
    
  },

});
