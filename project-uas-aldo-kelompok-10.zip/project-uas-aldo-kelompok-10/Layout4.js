import * as React from 'react';
import { Text, View, StyleSheet, Image ,Dimensions,TouchableOpacity} from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;

export default function App({navigation}) {
  return (
    <View>
    <View style={styles.container}>
      <View style={styles.Search} >
       <Ionicons name="arrow-back-sharp" size={25} color="black"/>
      <Text
      style={{
        width:320,
        height:25,
        fontWeight:"bold",
        marginLeft:245}}>
      <Ionicons name="reorder-four-outline" size={25} color="black"/> 
      </Text>
      </View>
      <View>
      <View
        style={{
          justifyContent:'center',
          alignItems:"center"
        }}>
        <Text
        style={{
        color:'#2A2E3A',
        width:100,
        fontWeight:'Algerian',
        alignItems:'center',
        justifyContent:'center',
        fontSize:40}}>
        Mans </Text>
        <Text
        style={{
        color:'#2A2E3A',
        width:180,
        fontWeight:'Algerian',
        alignItems:'center',
        justifyContent:'center',
        fontSize:40}}>
        Collection </Text>
        </View>
        
        

        <View style={styles.Menu1}>
        
        <View
        style={{
          marginTop:100,
        }}>
        <Ionicons name="arrow-back-sharp" size={25} color="black"/>
        </View>
        <View
        style={{
          marginTop:-25,
          width:100,
          height:160,
          borderColor:'#000000',
          borderWidth:0,
          borderRadius:40,
          alignItems:'center',
          justifyContent:'flex-end'}}>
      <Image style={styles.logo2} source={{uri:'https://i.pinimg.com/564x/d3/63/f3/d363f356a8b429661613506893d34b8b.jpg'}}/>
        
      </View>
      <View
        style={{
          marginTop:100,
        }}>
      <Ionicons name="arrow-forward-sharp" size={25} color="black"/>
      </View>
     </View>
        </View>
        
        </View>
        <View style={styles.buttomMenu}>
      <View>
         <TouchableOpacity onPress={()=>navigation.navigate('Layout5')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>10</Text></View>
          <Ionicons name="home" size={25} color="#c9c9d6"/>
      </TouchableOpacity>
      </View>
      

      <View>
      <TouchableOpacity onPress={()=>navigation.navigate('Layout3')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>1</Text></View>
      <Ionicons name="briefcase-sharp" size={25} color="#c9c9d6"/>
      </TouchableOpacity>
      </View>
      

      <View>
          <TouchableOpacity onPress={()=>navigation.navigate('Layout1')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>1</Text></View>
      <Ionicons name="calendar-sharp" size={25} color="#c9c9d6"/>
      </TouchableOpacity>
      </View>

      <View>
          <TouchableOpacity onPress={()=>navigation.navigate('Layout2')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>1</Text></View>
      <Ionicons name="finger-print-sharp" size={25} color="#c9c9d6"/>
      </TouchableOpacity>
      </View>

      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  buttomMenu:{
    height:70,
    backgroundColor:'grey',
    borderRadius:25,
    position:"relative",
    flexDirection:'row',
    justifyContent:"space-around",
    top:windowHeight-700,
    alignItems:'center',
    zIndex:9999
  },
  container: {
    flex: 4,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'white',
    padding:4,
  },
  Search: {
    flexDirection: 'row',
    margin: 15,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    justifyContent:"space-between"    
  },
  Menu1: {
    fontSize: 20,
    marginTop:5,
    fontWeight: 'bold',
    textAlign: 'center',
    justifyContent:'space-around',
    flexDirection:'row',
  },
  
  textbox: { 
    padding:10,
    flexDirection:'row',
    alignItems:'center',
    backgroundColor:'#d4d4d2',
    height:70,
    justifyContent:'center',
    borderRadius:30,
    marginTop:20
  },
  logo1:{
    height:100,
    width:100,
    borderRadius:1000,
    borderWidth:1,
    position:'flex'
    
  },
  logo2:{
    height:350,
    width:200,
    borderRadius:40,
    top:215,
    position:'flex'
    
  },
});
