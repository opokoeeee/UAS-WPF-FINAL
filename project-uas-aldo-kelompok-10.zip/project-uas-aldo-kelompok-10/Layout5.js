import React,{useState,useEffect} from 'react';
import { Text, View, StyleSheet, Image ,Dimensions,TouchableOpacity,FlatList} from 'react-native';
import Constants from 'expo-constants';
import axios from 'axios';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;

export default function Layout5({navigation}) {
  const [poster,setPoster]=useState([])
   const getPoster = async () => {
    try {
      const dataIsi = await axios.get(
        'https://morning-escarpment-62298.herokuapp.com/api/acara'
      );
      setPoster(dataIsi.data);
      console.log(dataIsi.data);
    } catch (err) {
      console.error(err.message);
    }
  };
  useEffect(()=>{
    getPoster()
},[])
    return(
      <>
    
    <View>
      <View >
      <View>
     <center>
     <Text
        style={{
        color:'#2A2E3A',
        width:120,
        fontWeight:'Algerian',
        justifyContent:'center',
        fontSize:30}}>
        ACARA
        </Text>
        </center>
      </View>
      
      <View ><FlatList
                   data={poster}
                   renderItem={({ item }) => (
                     <>
          <View style={{
                       marginLeft:8,
                       marginTop:10,
                       marginBottom:10,
                       justifyContent:"space-between",
                       flexDirection:"row-reverse",
                       alignItems:'center',
                       padding:10,
                       width:300,
                       borderRadius:20,
                       backgroundColor:'#ecbc4f'
                     }}>
                     <Ionicons name="chevron-back-outline" size={25} color="#FD60A9"/>
                      <View
                      style={{
                        flexDirection:'row',
                      }}
                      >
                          
                          <View>
                         
                           <Text
                          style={{
                            paddingLeft:20,
                            fontWeight:"bold"
                          }}
                          >Nama Acara : {item.nama_acara}</Text>
                           <Text
                          style={{
                            paddingLeft:20,
                            fontWeight:"bold"
                          }}
                          >Penanggung jawab : {item.id_penanggung_jawab.nama}</Text>
                           <Text
                          style={{
                            paddingLeft:20,
                            fontSize:12
                          }}
                          >Mulai Acara :{item.id_tanggal_acara.mulai_acara}</Text>
                          <Text
                          style={{
                            paddingLeft:20,
                            fontSize:12
                          }}
                          >Fasilitas Dipinjam :{item.id_fasilitas.nama_barang} </Text>
                          
                          

                          </View>
                          
                          <View>
                          
                          <View>
                          
                          </View>

                          </View>
          </View>
          
          </View>
          
          
        </>
                      )}
                   keyExtractor={({ id }, index) => id}
        />
      
      </View>
        
     

       <View style={styles.buttomMenu}>
      <View>
         <TouchableOpacity onPress={()=>navigation.navigate('Layout5')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>10</Text></View>
          <Ionicons name="home" size={25} color="black"/>
      </TouchableOpacity>
      </View>
      

      <View>
      <TouchableOpacity onPress={()=>navigation.navigate('Layout3')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>1</Text></View>
      <Ionicons name="briefcase-sharp" size={25} color="black"/>
      </TouchableOpacity>
      </View>
      

      <View>
          <TouchableOpacity onPress={()=>navigation.navigate('Layout1')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>1</Text></View>
      <Ionicons name="calendar-sharp" size={25} color="black"/>
      </TouchableOpacity>
      </View>

      <View>
          <TouchableOpacity onPress={()=>navigation.navigate('Layout2')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>1</Text></View>
      <Ionicons name="finger-print-sharp" size={25} color="black"/>
      </TouchableOpacity>
      </View>
      </View>
      </View>
      
      
    </View>
    </>
  );
}

const styles = StyleSheet.create({
  buttomMenu:{
    height:70,
    backgroundColor:'#5caaf0',
    borderRadius:25,
    position:"relative",
    flexDirection:'row',
    justifyContent:"space-around",
    top:windowHeight-670,
    alignItems:'center',
    zIndex:9999
  },
  container: {
    flex: 4,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'white',
    padding:4,

  },
  Search: {
    flexDirection: 'row',
    margin: 15,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    justifyContent:"space-between"    
  },
  Menu1: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    justifyContent:'space-around',
    flexDirection:'row',
    margin:15,
  },
  
  textbox: {
    padding:10,
    flexDirection:'row',
    alignItems:'center',
    backgroundColor:'#d4d4d2',
    height:70,
    justifyContent:'space-between',
    borderRadius:30,
    marginTop:20
  },
  logo1:{
    height:55,
    width:75,
    borderRadius:20,
    borderWidth:1,
    position:'flex'
    
  },
});