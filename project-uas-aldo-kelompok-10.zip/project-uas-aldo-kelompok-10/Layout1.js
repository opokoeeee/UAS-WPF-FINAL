import React from 'react';
import axios from 'axios';
import Constants from 'expo-constants';
import { FlatList, ActivityIndicator, StyleSheet, Image, Text, View,Dimensions,TouchableOpacity } from 'react-native';
 
// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;

export default class Layout1 extends React.Component  {
   constructor(props) {
       super(props);
       this.state = { isLoading: true };
   }
 
   componentDidMount() {
       axios.get(`https://morning-escarpment-62298.herokuapp.com/api/tanggalacara`)
           .then(response => {
               console.log(response.data)
               this.setState(
                   {
                       isLoading: false,
                       dataSource: response.data
                   })
           })
           .catch(error => {
               console.log(error)
           })
   }
 
   render() {
       return (
         <View>
    <View style={styles.container}>
      <View>
     <center>
     <Text
        style={{
        
        color:'#2A2E3A',
        width:120,
        fontStyle:'Bauhaus 93',
        fontWeight:'bold',
        justifyContent:'center',
        fontSize:30}}>
        Tanggal Acara
        </Text>
        </center>
      </View>
      <View style={styles.Search}>
      <View
       style={{
       width:300,
       height:46,
       borderColor:'black',
       borderWidth:1,
       borderRadius:20,
       left:-10,
       flexDirection:'row',
       alignItems:"center"
       }}>
      <Ionicons 
      style={{
       marginLeft:15}}
       name="search" size={25} color="black" />
      <Text
     style={{
       fontSize:12,
       fontWeight:"bold",
       marginLeft:20}}>
       Search Product
    </Text>
    </View>
      </View>

      <View style={styles.Menu1}>
      <TouchableOpacity onPress={()=>this.props.navigation.navigate('Layout5')}>
      <View
      style={{
       width:60,
       height:60,
       borderColor:'#000000',
       borderWidth:0,
       borderRadius:20,
       alignItems:'center',
       justifyContent:'center',
       marginRight:1}}>
      
      <Ionicons name="home" size={25} color="#08c5d3"/>
      <Text
        style={{
          width:35,
          height:30,
          marginRight:0,
          marginLeft:0,
          fontSize:9}}>
        Acara
      </Text>
      </View>
      </TouchableOpacity>

      <TouchableOpacity onPress={()=>this.props.navigation.navigate('Layout3')}>
      <View
       style={{
       width:60,
       height:60,
       borderColor:'#000000',
       borderWidth:0,
       borderRadius:20,
       alignItems:'center',
       justifyContent:'center',
       marginRight:1}}>
       <Ionicons name="briefcase-sharp" size={25} color="#5e5150"/>
       <Text
        style={{
          width:45,
          height:30,
          marginRight:0,
          marginLeft:0,
          fontSize:9}}>
        Fasilitas
      </Text>
      </View>
      </TouchableOpacity>
       <TouchableOpacity onPress={()=>this.props.navigation.navigate('Layout1')}>
      <View
       style={{
       width:60,
       height:60,
       borderColor:'#000000',
       borderWidth:0,
       borderRadius:20,
       alignItems:'center',
       justifyContent:'center',
       marginRight:1}}>
       <Ionicons name="calendar-sharp" size={25} color="#e38657"/>
       <Text
        style={{
          width:45,
          height:30,
          marginRight:0,
          marginLeft:0,
          fontSize:9}}>
        Tanggal Acara
      </Text>
      </View>
      </TouchableOpacity>

       <TouchableOpacity onPress={()=>this.props.navigation.navigate('Layout2')}>
      <View
       style={{
       width:60,
       height:60,
       borderColor:'#000000',
       borderWidth:0,
       borderRadius:20,
       alignItems:'center',
       justifyContent:'center',
       marginRight:10}}>
       <Ionicons name="finger-print-sharp" size={25} color="#3f5b76"/>
       <Text
        style={{
          width:60,
          height:30,
          marginRight:0,
          marginLeft:2,
          fontSize:9}}>
        Penanggung 
        Jawab
      </Text>
      </View>
      </TouchableOpacity>
      </View>
<FlatList
                   data={this.state.dataSource}
                   renderItem={({ item }) => (
                     <>
      <View style={styles.textbox}>
      <View>

      <View style={{
        left:15,
        width:200,
        flexDirection:'row'
      }}>
     
     <View>
      <Text
      style={{
        color:'#2A2E3A',
        fontWeight:'bold',
        fontSize:15
      }}
      >Mulai Acara : {item.mulai_acara}</Text>
     <Text
     style={{
        color:'#2A2E3A',
        fontWeight:'bold',
        fontSize:15
      }}
     >Penutupan Acara : {item.penutupan_acara}</Text>
     <Text
     style={{
        color:'#999CA8',
        fontSize:12
      }}
     >Berlangsungnya Acara : {item.lama_acara_berlangsung} Hari
     </Text>
     </View>
      </View>
      </View>
      </View>
                     </>
                      )}
                   keyExtractor={({ id }, index) => id}
        />
     


      
      
    </View>
    <View style={styles.buttomMenu}>
      <View>
         <TouchableOpacity onPress={()=>this.props.navigation.navigate('Layout5')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>10</Text></View>
          <Ionicons name="home" size={25} color="black"/>
      </TouchableOpacity>
      </View>
      

      <View>
      <TouchableOpacity onPress={()=>this.props.navigation.navigate('Layout3')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>1</Text></View>
      <Ionicons name="briefcase-sharp" size={25} color="black"/>
      </TouchableOpacity>
      </View>
      

      <View>
          <TouchableOpacity onPress={()=>this.props.navigation.navigate('Layout1')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>1</Text></View>
      <Ionicons name="calendar-sharp" size={25} color="black"/>
      </TouchableOpacity>
      </View>

      <View>
          <TouchableOpacity onPress={()=>this.props.navigation.navigate('Layout2')}>
          <View
          style={{
            backgroundColor:'red',
            width:15,
            height:15,
            borderRadius:20,
            position:"absolute",
            left:12,
            alignItems:'center',
            justifyContent:'center'
          }}
          ><Text style={{
            color:'white',
            textAlign:"center",
            fontSize:12
          }}>1</Text></View>
      <Ionicons name="finger-print-sharp" size={25} color="black"/>
      </TouchableOpacity>
      </View>

      </View>
    </View>
       );
   }
 
}
const styles = StyleSheet.create({
  buttomMenu:{
    height:70,
    backgroundColor:'#5caaf0',
    borderRadius:25,
    position:"relative",
    flexDirection:'row',
    justifyContent:"space-around", 
    top:windowHeight -700 ,
    alignItems:'center',
    zIndex:9999
  },
  container: {
    flex: 1,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  Search: {
    flexDirection: 'row',
    margin: 20,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    justifyContent:"space-between"    
  },
  Menu1: {
    fontSize: 20,
    marginTop:5,
    fontWeight: 'bold',
    textAlign: 'center',
    justifyContent:'space-around',
    flexDirection:'row',
  },
  
  textbox: {
    padding:10,
    flexDirection:'row',
    alignItems:'center',
    backgroundColor:'#e8ecee',
    height:60,
    justifyContent:'space-between',
    borderRadius:30,
    marginTop:10
  },
  logo1:{
    height:55,
    width:75,
    borderRadius:20,
    borderWidth:1,
    position:'flex'
    
  },

});




